

create table Customer (
	Id int identity(1,1) PRIMARY KEY,
	FirstName varchar(50),
	LastName varchar(50),
	Phone varchar(10)
)

create table Customer_Addresses(
	Id int IDENTITY(1,1) primary key,
	City varchar(50),
	Country varchar(50),
	Customer_Id int,
	Constraint FK_Customer_Address_Customer_Id Foreign key (Customer_Id) references Customer(Id)
); 

insert into Customer values ('demo1','lname','1020304050');
insert into Customer_Addresses values('ahd','123',1)
insert into Customer_Addresses values('qaz','321',1)

select * from Customer
select * from Customer_Addresses

create table Category (Id int identity(1,1) primary key, c_ame varchar(50));
create table Product (Id int identity(1,1) primary key,
		p_name varchar(50),
			description varchar(250),
			price decimal(18,2),
			img varchar(max),
			c_id int,
			Constraint FK_Product_Category_Id Foreign key (c_id) references Category(Id));
select * from Category;
select * from Product

insert into Category values ('nirav');
insert into Product values('1jasvc','abc',120,'demo.png',1);