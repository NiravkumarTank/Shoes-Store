import { Component, OnInit } from '@angular/core';
import { ApiDemoService } from '../../api-demo.service';
import { Category, Product } from '../interface/envarment';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-add',
  standalone: false,
  templateUrl: './product-add.component.html',
  styleUrl: './product-add.component.css'
})
export class ProductAddComponent implements OnInit{
  product: Product = new Product();  // Model for the product to be added
  categories: Category[] = [];  // To hold the list of categories

  constructor(private apiService: ApiDemoService, private router: Router) { }

  ngOnInit(): void {
    // Fetch categories to populate the dropdown
    this.apiService.getCategories().subscribe(
      (data) => {
        this.categories = data;
      },
      (error) => {
        console.error('Error fetching categories:', error);
      }
    );
  }

  addProduct(): void {
    this.apiService.addProduct(this.product).subscribe(
      (response) => {
        console.log('Product added successfully:', response);
        this.router.navigate(['/product-list']); 
      },
      (error) => {
        console.error('Error adding product:', error);
      }
    );
  }
}
