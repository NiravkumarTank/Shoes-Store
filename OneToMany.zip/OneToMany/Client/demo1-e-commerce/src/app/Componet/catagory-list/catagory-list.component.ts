import { Component, OnInit } from '@angular/core';
import { ApiDemoService } from '../../api-demo.service';
import { Category } from '../interface/envarment';

@Component({
  selector: 'app-catagory-list',
  standalone: false,
  templateUrl: './catagory-list.component.html',
  styleUrl: './catagory-list.component.css'
})
export class CatagoryListComponent implements OnInit{
  categories: Category[] = [];  // Array to store fetched categories

  constructor(private apiService: ApiDemoService) { }

  ngOnInit(): void {
    // Fetch all categories when the component initializes
    this.apiService.getAllCategories().subscribe(
      (data) => {
        this.categories = data;  // Store the fetched categories
      },
      (error) => {
        console.error('Error fetching categories:', error);
      }
    );
  }
}
