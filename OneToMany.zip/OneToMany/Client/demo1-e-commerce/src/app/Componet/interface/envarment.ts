export interface Category {
    id: number;
    c_ame?: string;
  }
  
  export class Product {
    id: number = 0;
    p_name: string = '';
    description: string = '';
    price: number = 0;
    img: string = '';
    c_id: number = 0; 
    category_name?: string;
  }
  