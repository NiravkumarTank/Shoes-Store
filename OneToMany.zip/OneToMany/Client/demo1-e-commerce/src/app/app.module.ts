import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CatagoryAddComponent } from './Componet/catagory-add/catagory-add.component';
import { CatagoryListComponent } from './Componet/catagory-list/catagory-list.component';
import { ProductAddComponent } from './Componet/product-add/product-add.component';
import { ProductListComponent } from './Componet/product-list/product-list.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    CatagoryAddComponent,
    CatagoryListComponent,
    ProductAddComponent,
    ProductListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
