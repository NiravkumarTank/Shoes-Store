import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CatagoryAddComponent } from './Componet/catagory-add/catagory-add.component';
import { CatagoryListComponent } from './Componet/catagory-list/catagory-list.component';
import { ProductAddComponent } from './Componet/product-add/product-add.component';
import { ProductListComponent } from './Componet/product-list/product-list.component';

const routes: Routes = [
  {path : "" ,component:CatagoryAddComponent},
  {path : "catagory-add" ,component:CatagoryAddComponent},
  {path : "catagory-list" ,component:CatagoryListComponent},
  {path : "product-add" ,component:ProductAddComponent},
  {path : "product-list" ,component:ProductListComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
