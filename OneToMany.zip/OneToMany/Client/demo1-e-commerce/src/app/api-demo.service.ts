import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Category, Product } from './Componet/interface/envarment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiDemoService {

  
  private apiUrl = 'https://localhost:7085/api'; // Replace with your actual API URL

  constructor(private http: HttpClient) { }

  addCategory(category: Category): Observable<Category> {
    return this.http.post<Category>(this.apiUrl + "/Category/Post", category);
  }


  getAllCategories(): Observable<Category[]> {
    return this.http.get<Category[]>(this.apiUrl + "/Category/Get");  // Making the GET request to fetch categories
  }



  // Get all products
  getAllProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl + "/Product");
  }

  // Get all categories
  getCategories(): Observable<Category[]> {
    return this.http.get<Category[]>(this.apiUrl+ "/Product/categories");  // Fetch categories
  }

  // Add new product
  addProduct(product: Product): Observable<Product> {
    return this.http.post<Product>(this.apiUrl + "/Product", product);
  }



}
