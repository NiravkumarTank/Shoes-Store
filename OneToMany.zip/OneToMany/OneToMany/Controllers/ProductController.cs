﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OneToMany.Dtos;
using OneToMany.Entity;
using Microsoft.EntityFrameworkCore;

namespace OneToMany.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly OneToManyContext _context;

        public ProductController(IMapper mapper, OneToManyContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        // POST: api/Product
        [HttpPost]
        public async Task<IActionResult> CreateProduct([FromBody] ProductDTO productDTO)
        {
            if (productDTO == null)
            {
                return BadRequest("Product data is required.");
            }

            var product = _mapper.Map<Product>(productDTO);
            _context.Product.Add(product);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetProduct), new { id = product.Id }, product);
        }

        // GET: api/Product
        [HttpGet]
        public async Task<IActionResult> GetProducts()
        {
            var products = await _context.Product
                .Include(p => p.Category)  // Include related Category entity if needed
                .ToListAsync();

            var productDTOs = _mapper.Map<List<ProductDTO>>(products);
            return Ok(productDTOs);
        }

        // GET: api/Product/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduct(int id)
        {
            var product = await _context.Product
                .Include(p => p.Category)  // Include related Category entity if needed
                .FirstOrDefaultAsync(p => p.Id == id);

            if (product == null)
            {
                return NotFound($"Product with id {id} not found.");
            }

            var productDTO = _mapper.Map<ProductDTO>(product);
            return Ok(productDTO);
        }
    }
}
