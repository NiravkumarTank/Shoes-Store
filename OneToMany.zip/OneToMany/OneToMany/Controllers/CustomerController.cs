﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OneToMany.Dtos;
using OneToMany.Entity;

namespace OneToMany.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        public readonly OneToManyContext _context;
        private readonly IMapper _mapper;

        public CustomerController(OneToManyContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }


        [HttpGet]
        public async Task<IActionResult> Get() 
        {
            var customer = await _context.Customer
                    .Include( p => p.CustomerAddresses).ToListAsync();
            return Ok(customer);
        }


        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var customer = await _context.Customer
                    .Include(p => p.CustomerAddresses).Where(p=>p.Id == id).FirstOrDefaultAsync();
            return Ok(customer);
        }

    

        [HttpPost]
        public async Task<IActionResult> Post(CustomerDTO payloadCustomer)
        {
            var newCustomer = _mapper.Map<Customer>(payloadCustomer);
            _context.Customer.Add(newCustomer);
            await _context.SaveChangesAsync();
            return Created($"/customer/{newCustomer.Id}", newCustomer);

        }

    }
}
