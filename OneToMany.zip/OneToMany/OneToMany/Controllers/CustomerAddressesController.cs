﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OneToMany.Dtos;
using OneToMany.Entity;
using Microsoft.EntityFrameworkCore;

namespace OneToMany.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerAddressesController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly OneToManyContext _context;

        public CustomerAddressesController(IMapper mapper, OneToManyContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        // POST: api/CustomerAddresses
        [HttpPost]
        public async Task<IActionResult> CreateCustomerAddress([FromBody] CustomerAddressesDTO customerAddressesDTO)
        {
            if (customerAddressesDTO == null)
            {
                return BadRequest("Customer address data is required.");
            }

            var customerAddress = _mapper.Map<CustomerAddresses>(customerAddressesDTO);
            _context.Customer_Addresses.Add(customerAddress);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCustomerAddress), new { id = customerAddress.Id }, customerAddress);
        }

        // GET: api/CustomerAddresses
        // GET: api/CustomerAddresses
        [HttpGet]
        public async Task<IActionResult> GetCustomerAddresses()
        {
            var customerAddresses = await _context.Customer_Addresses
                .Include(ca => ca.Customer)  // Include related Customer entity if needed
                .ToListAsync();

            var customerAddressesDTO = _mapper.Map<List<CustomerAddressesDTO>>(customerAddresses);
            return Ok(customerAddressesDTO);
        }


        // GET: api/CustomerAddresses/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCustomerAddress(int id)
        {
            var customerAddress = await _context.Customer_Addresses
                .Include(ca => ca.Customer)  // Include related Customer entity if needed
                .FirstOrDefaultAsync(ca => ca.Id == id);

            if (customerAddress == null)
            {
                return NotFound($"Customer address with id {id} not found.");
            }

            var customerAddressDTO = _mapper.Map<CustomerAddressesDTO>(customerAddress);
            return Ok(customerAddressDTO);
        }
    }
}
