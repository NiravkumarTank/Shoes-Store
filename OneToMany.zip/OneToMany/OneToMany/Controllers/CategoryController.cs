﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OneToMany.Dtos;
using OneToMany.Entity;

namespace OneToMany.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        public readonly OneToManyContext _context;
        private readonly IMapper _mapper;

        public CategoryController(OneToManyContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        // GET: api/category
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var categories = await _context.Category
                    .Include(p => p.Product) // If you want to include products in the category
                    .ToListAsync();
            return Ok(categories);
        }

        // GET: api/category/{id}
        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var category = await _context.Category
                    .Include(p => p.Product) // Include related products if needed
                    .Where(p => p.Id == id)
                    .FirstOrDefaultAsync();

            if (category == null)
            {
                return NotFound();
            }

            return Ok(category);
        }

        // POST: api/category
        [HttpPost]
        public async Task<IActionResult> Post(CategoryDTO payloadCategory)
        {
            var newCategory = _mapper.Map<Category>(payloadCategory);
            _context.Category.Add(newCategory);
            await _context.SaveChangesAsync();
            return Created($"/category/{newCategory.Id}", newCategory);
        }
    }
}
