﻿using Microsoft.EntityFrameworkCore;

namespace OneToMany.Entity
{
    public class OneToManyContext : DbContext
    {
        public OneToManyContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet <Customer> Customer { get; set; }
        public DbSet <CustomerAddresses> Customer_Addresses { get; set; }

        public DbSet<Category> Category { get; set; }
        public DbSet<Product> Product { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<CustomerAddresses>()
                .HasOne(p => p.Customer)
                .WithMany(p => p.CustomerAddresses)
                .HasForeignKey(P => P.Customer_Id);

            modelBuilder.Entity<Product>()
               .HasOne(p => p.Category)
               .WithMany(p => p.Product)
               .HasForeignKey(P => P.c_id);
        }
    }
}
