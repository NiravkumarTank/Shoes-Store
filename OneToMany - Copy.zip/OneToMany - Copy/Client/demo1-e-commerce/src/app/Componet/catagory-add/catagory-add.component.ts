import { Component } from '@angular/core';
import { Category } from '../interface/envarment';
import { ApiDemoService } from '../../api-demo.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-catagory-add',
  standalone: false,
  templateUrl: './catagory-add.component.html',
  styleUrl: './catagory-add.component.css'
})
export class CatagoryAddComponent {
  category: Category = { id: 0, c_ame: '' };

  constructor(private apiService: ApiDemoService , private router: Router) {}

  addCategory() {
    this.apiService.addCategory(this.category).subscribe(response => {
      console.log('Category added:', response);
      // Optionally reset form or redirect
      this.router.navigate(['/catagory-list']); 
    });
  }
}
