import { Component, OnInit } from '@angular/core';
import { ApiDemoService } from '../../api-demo.service';
import { Category, Product } from '../interface/envarment';

@Component({
  selector: 'app-product-list',
  standalone: false,
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent implements OnInit{



  products: Product[] = [];  // Array to store fetched products
  categories: Category[] = []; // Array to store categories

  constructor(private apiService: ApiDemoService) { }

  // ngOnInit(): void {
  //   // Fetch the products when the component is initialized
  //   this.apiService.getAllProducts().subscribe(
  //     (productData) => {
  //       this.products = productData;  // Store the fetched products in the array

  //       // Fetch the categories and map category names to products
  //       this.apiService.getCategories().subscribe(
  //         (categoryData) => {
  //           this.categories = categoryData; // Store the categories
            
  //           // Now map category names to products
  //           this.products.forEach((product) => {
  //             // Find category by c_id and assign category_name to the product
  //             const category = this.categories.find(c => c.id === product.c_id);
  //             if (category) {
  //               product.category_name = category.c_ame; // Assign the category name
  //             }
  //           });
  //         },
  //         (error) => {
  //           console.error('Error fetching categories:', error);
  //         }
  //       );
  //     },
  //     (error) => {
  //       console.error('Error fetching products:', error);
  //     }
  //   );
  // }

  ngOnInit(): void {
    // Fetch the products when the component is initialized
    this.apiService.getAllProducts().subscribe(
      (productData) => {
        this.products = productData;  // Store the fetched products in the array
  
        // Fetch the categories and map category names to products
        this.apiService.getCategories().subscribe(
          (categoryData) => {
            this.categories = categoryData; // Store the categories
            
            // Now map category names to products
            this.products.forEach((product) => {
              // Find category by c_id and assign category_name to the product
              const category = this.categories.find(c => c.id === product.c_id);
              if (category) {
                product.category_name = category.c_ame;  // Corrected property name
              }
            });
          },
          (error) => {
            console.error('Error fetching categories:', error);
          }
        );
      },
      (error) => {
        console.error('Error fetching products:', error);
      }
    );
  }
  
}
