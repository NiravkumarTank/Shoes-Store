// export interface Category {
//     id: number;
//     c_ame?: string;
//   }
  
//   export class Product {
//     id: number = 0;
//     p_name: string = '';
//     description: string = '';
//     price: number = 0;
//     img: string = '';
//     c_id: number = 0; 
//     category_name?: string;

//     filename?: File; 
//   }
export interface Category {
  id: number;
  c_ame?: string;
}

export class Product {
  id: number = 0;
  p_name: string = '';
  description: string = '';
  price: number = 0;
  img: string = '';  // This will store the file name after it's uploaded
  c_id: number = 0;
  category_name?: string;

  // Temporary file object for upload
  filename?: File;  // This will hold the file from the file input field
}
