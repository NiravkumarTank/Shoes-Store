import { Component, OnInit } from '@angular/core';
import { ApiDemoService } from '../../api-demo.service';
import { Category, Product } from '../interface/envarment';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-add',
  standalone: false,
  templateUrl: './product-add.component.html',
  styleUrl: './product-add.component.css'
})
export class ProductAddComponent implements OnInit{
  // product: Product = new Product();  // Model for the product to be added
  // categories: Category[] = [];  // To hold the list of categories

  // constructor(private apiService: ApiDemoService, private router: Router) { }

  // ngOnInit(): void {
  //   // Fetch categories to populate the dropdown
  //   this.apiService.getCategories().subscribe(
  //     (data) => {
  //       this.categories = data;
  //     },
  //     (error) => {
  //       console.error('Error fetching categories:', error);
  //     }
  //   );
  // }

  // addProduct(): void {
  //   this.apiService.addProduct(this.product).subscribe(
  //     (response) => {
  //       console.log('Product added successfully:', response);
  //       this.router.navigate(['/product-list']); 
  //     },
  //     (error) => {
  //       console.error('Error adding product:', error);
  //     }
  //   );
  // }

  product: Product = new Product(); // Model for the product to be added
  categories: Category[] = []; // To hold the list of categories

  constructor(private apiService: ApiDemoService, private router: Router) {}

  ngOnInit(): void {
    // Fetch categories to populate the dropdown
    this.apiService.getCategories().subscribe(
      (data) => {
        this.categories = data;
      },
      (error) => {
        console.error('Error fetching categories:', error);
      }
    );
  }

  // Handle file input change event and set the file
  onFileChange(event: any): void {
  const file = event.target.files[0];
  if (file) {
    this.product.filename = file;
  }
}


  addProduct(): void {
    const formData = new FormData();
    formData.append('p_name', this.product.p_name);
    formData.append('description', this.product.description);
    formData.append('price', this.product.price.toString());
    formData.append('c_id', this.product.c_id.toString());
    if (this.product.filename) {
      formData.append('filename', this.product.filename); // Add the file to the form data
    }

    this.apiService.addProduct(formData).subscribe(
      (response :any) => {
        console.log('Product added successfully:' + response.message);
        alert(response.message)
        this.router.navigate(['/product-list']);
      },
      (error) => {
        console.error('Error adding product:', error);
      }
    );
  }
}
