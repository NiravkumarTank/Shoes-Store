﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OneToMany.Dtos;
using OneToMany.Entity;

namespace OneToMany.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        public readonly OneToManyContext _context;
        private readonly IMapper _mapper;

        public CategoryController(OneToManyContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        // GET: api/category
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var categories = await _context.Category
                    .Include(p => p.Product) // If you want to include products in the category
                    .ToListAsync();
            return Ok(categories);
        }

        // GET: api/category/{id}
        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var category = await _context.Category
                    .Include(p => p.Product) // Include related products if needed
                    .Where(p => p.Id == id)
                    .FirstOrDefaultAsync();

            if (category == null)
            {
                return NotFound();
            }

            return Ok(category);
        }

        // POST: api/category
        [HttpPost]
        public async Task<IActionResult> Post(CategoryDTO payloadCategory)
        {
            var newCategory = _mapper.Map<Category>(payloadCategory);
            _context.Category.Add(newCategory);
            await _context.SaveChangesAsync();
            return Created($"/category/{newCategory.Id}", newCategory);
        }


        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                // Fetch the category and its related products
                var category = await _context.Category
                    .Include(c => c.Product)
                    .FirstOrDefaultAsync(c => c.Id == id);

                // If the category doesn't exist, return NotFound
                if (category == null)
                {
                    return NotFound();
                }

                // Remove the category (this will cascade delete the products)
                _context.Category.Remove(category);
                await _context.SaveChangesAsync();

                // Optionally, return the deleted category Id
                return Ok(new { message = "Category and related products deleted", categoryId = id });
            }
            catch (Exception ex)
            {
                // Log the exception (optional)
                // Return a generic error message
                return StatusCode(500, "An error occurred while deleting the category.");
            }
        }


        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> Update(int id, CategoryDTO payloadCategory)
        {
            if (payloadCategory == null)
            {
                return BadRequest("Category data is required.");
            }

            // Fetch the category by Id
            var category = await _context.Category
                .FirstOrDefaultAsync(c => c.Id == id);

            // If category doesn't exist, return NotFound
            if (category == null)
            {
                return NotFound($"Category with id {id} not found.");
            }

            // Map the updated data from the DTO to the existing category
            _mapper.Map(payloadCategory, category);

            // Save the changes to the database
            await _context.SaveChangesAsync();

            // Return the updated category
            return Ok(category);  // You can return a 200 status code with the updated category object
        }

    }
}
