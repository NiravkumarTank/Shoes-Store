﻿//using AutoMapper;
//using OneToMany.Dtos;
//using OneToMany.Entity;

//namespace OneToMany
//{
//    public class AppMapperProfile : Profile
//    {
//        public AppMapperProfile()
//        {
//            // Mapping for single CustomerDTO to Customer
//            CreateMap<CustomerDTO, Customer>();

//            // Mapping for single CustomerAddressesDTO to CustomerAddresses
//            CreateMap<CustomerAddressesDTO, CustomerAddresses>();
//            CreateMap<CategoryDTO, Category>();
//            CreateMap<ProductDTO, Product>();

//            // Mapping for List of CustomerAddresses to List of CustomerAddressesDTO
//            CreateMap<List<CustomerAddresses>, List<CustomerAddressesDTO>>()
//                .ConvertUsing(src => src.Select(x => new CustomerAddressesDTO
//                {
//                    Id = x.Id,
//                    City = x.City,
//                    Country = x.Country,
//                    Customer_Id = x.Customer_Id
//                }).ToList());

//            // Mapping for List of CustomerAddressesDTO to List of CustomerAddresses
//            CreateMap<List<CustomerAddressesDTO>, List<CustomerAddresses>>()
//                .ConvertUsing(src => src.Select(x => new CustomerAddresses
//                {
//                    Id = x.Id,
//                    City = x.City,
//                    Country = x.Country,
//                    Customer_Id = x.Customer_Id
//                }).ToList());


//            CreateMap<List<Product>, List<ProductDTO>>()
//               .ConvertUsing(src => src.Select(x => new ProductDTO
//               {
//                   Id = x.Id,
//                   p_name = x.p_name,
//                   description = x.description,
//                   img= x.img,
//                   price = x.price,
//                   c_id = x.c_id,

//               }).ToList());


//            CreateMap<List<ProductDTO>, List<Product>>()
//              .ConvertUsing(src => src.Select(x => new Product
//              {
//                  Id = x.Id,
//                  p_name = x.p_name,
//                  description = x.description,
//                  img = x.img,
//                  price = x.price,
//                  c_id = x.c_id,

//              }).ToList());
//        }
//    }
//}

using AutoMapper;
using OneToMany.Dtos;
using OneToMany.Entity;

namespace OneToMany
{
    public class AppMapperProfile : Profile
    {
        public AppMapperProfile()
        {
            CreateMap<CategoryDTO, Category>();
            CreateMap<ProductDTO, Product>();

            //// Mapping for Product to ProductDTO and vice versa
            //CreateMap<Product, ProductDTO>()
            //    .ForMember(dest => dest.p_name, opt => opt.MapFrom(src => src.p_name))
            //    .ForMember(dest => dest.description, opt => opt.MapFrom(src => src.description))
            //    .ForMember(dest => dest.price, opt => opt.MapFrom(src => src.price))
            //    .ForMember(dest => dest.filename, opt => opt.MapFrom(src => src.img))
            //    .ForMember(dest => dest.c_id, opt => opt.MapFrom(src => src.c_id));

            //CreateMap<ProductDTO, Product>()
            //    .ForMember(dest => dest.p_name, opt => opt.MapFrom(src => src.p_name))
            //    .ForMember(dest => dest.description, opt => opt.MapFrom(src => src.description))
            //    .ForMember(dest => dest.price, opt => opt.MapFrom(src => src.price))
            //    .ForMember(dest => dest.img, opt => opt.MapFrom(src => src.img))
            //    .ForMember(dest => dest.c_id, opt => opt.MapFrom(src => src.c_id));

            // Mapping for List of Product to List of ProductDTO
            CreateMap<List<Product>, List<ProductDTO>>()
                .ConvertUsing(src => src.Select(x => new ProductDTO
                {
                    Id = x.Id,
                    p_name = x.p_name,
                    description = x.description,
                    img = x.img,
                    price = x.price,
                    c_id = x.c_id,
                }).ToList());

            // Mapping for List of ProductDTO to List of Product
            CreateMap<List<ProductDTO>, List<Product>>()
                .ConvertUsing(src => src.Select(x => new Product
                {
                    Id = x.Id,
                    p_name = x.p_name,
                    description = x.description,
                    img = x.img,
                    price = x.price,
                    c_id = x.c_id,
                }).ToList());

        }
    }
}
