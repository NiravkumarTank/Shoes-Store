﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OneToMany.Entity
{
    public class Product
    {

        public int Id { get; set; }
        public string? p_name { get; set; }
        public string? description { get; set; }
        public decimal? price { get; set; }
        public string? img { get; set; }
        public int c_id { get; set; }

        public Category Category { get; set; }


    }
}
