﻿using Microsoft.EntityFrameworkCore;

namespace OneToMany.Entity
{
    public class OneToManyContext : DbContext
    {
        public OneToManyContext(DbContextOptions options) : base(options)
        {
        }


        public DbSet<Category> Category { get; set; }
        public DbSet<Product> Product { get; set; }

        // Configure model relationships
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

           
            // Existing relationships for Product and Category
            modelBuilder.Entity<Product>()
                .HasOne(p => p.Category)
                .WithMany(p => p.Product)
                .HasForeignKey(P => P.c_id);

            

        }
    }
}
