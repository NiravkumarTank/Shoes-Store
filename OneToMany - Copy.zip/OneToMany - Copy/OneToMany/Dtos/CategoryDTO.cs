﻿using OneToMany.Entity;

namespace OneToMany.Dtos
{
    public class CategoryDTO
    {
        public int Id { get; set; }
        public string? c_ame { get; set; }

    }
}
