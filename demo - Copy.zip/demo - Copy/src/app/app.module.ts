import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component'; // Keep non-standalone component here
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

// Import standalone components here
import { FooterComponent } from './footer/footer.component'; 
import { DashboardComponent } from './dashboard/dashboard.component';
import { CartComponent } from './cart/cart.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent, // Keep this in declarations since it's not standalone
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,  // Import FormsModule to handle ngModel
    RouterModule,  // Import RouterModule for routing
    FooterComponent,  // Import standalone FooterComponent here
    DashboardComponent,  // Import standalone DashboardComponent here
    CartComponent,  // Import standalone CartComponent here
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
