import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Product } from './product.model';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cart: Product[] = [];
  private cartSubject = new BehaviorSubject<Product[]>(this.cart); // Keep the BehaviorSubject

  constructor() {
    this.loadCartFromLocalStorage();
  }

  private loadCartFromLocalStorage() {
    const cartData = localStorage.getItem('cart');
    if (cartData) {
      this.cart = JSON.parse(cartData);
      this.cartSubject.next([...this.cart]); // Update the BehaviorSubject with the loaded cart
    }
  }

  private saveCartToLocalStorage() {
    localStorage.setItem('cart', JSON.stringify(this.cart));
  }

  addToCart(product: Product) {
    const existingProduct = this.cart.find(p => p.id === product.id);

    if (existingProduct) {
      existingProduct.count++;
    } else {
      product.count = 1;
      this.cart.push(product);
    }

    this.cartSubject.next([...this.cart]);
    this.saveCartToLocalStorage();
  }

  getCartProducts() {
    return this.cartSubject.asObservable(); // Return the observable for cart products
  }

  removeFromCart(productId: number) {
    this.cart = this.cart.filter(product => product.id !== productId);
    this.cartSubject.next([...this.cart]);
    this.saveCartToLocalStorage();
  }

  clearCart() {
    this.cart = [];
    this.cartSubject.next([...this.cart]);
    this.saveCartToLocalStorage();  // Clear the local storage
  }

  getCartCount() {
    return this.cart.reduce((total, product) => total + product.count, 0);
  }

  getTotalPrice() {
    return this.cart.reduce((total, product) => total + (product.price * product.count), 0);
  }
}
